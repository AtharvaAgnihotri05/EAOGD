# Exploratory-Analysis-Of-Geolocational-Data
This project involves the use of K-Means Clustering to find the best accommodation for students in  any city of your choice by classifying accommodation for incoming students on the basis of their preferences on amenities, budget and proximity to the location.

# The project consists of the following stages:
![ME_ME_PROJECT_GEODATA_ANALYSIS_MODULE_ME_PROJECT_GEODATA_ANALYSIS_MODULE_GEODATA_ANALYSIS_Project-Steps](https://user-images.githubusercontent.com/64399192/179206460-a263b117-b505-468f-b92e-0aa6440de9ce.png)

# Result after implementation
<img width="959" alt="Screenshot 2022-07-15 160502" src="https://user-images.githubusercontent.com/64399192/179208455-7813e108-b0e6-45ad-96ad-679f3ad9c96f.png">

# By Observation 
1. Cluster 0 (Green) has more restaurents but less gyms and cafes.
2. Cluster 1 (Orange) has maximum restaurents,gyms and cafes.
3. Cluster 2 (Red) has less cafes but more gyms and restaurents.
